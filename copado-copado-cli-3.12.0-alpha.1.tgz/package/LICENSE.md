# Copado CLI — End User License Agreement (EULA)

**Licensor:** Copado Solutions and its affiliates (**“Copado”**).  
**Software:** The Copado CLI Salesforce plugin and related command-line tools distributed by Copado as **“Copado CLI”** (including updates Copado may provide).

By downloading, installing, or using Copado CLI, you agree to this EULA. If you do not agree, do not install or use the Software.

If you are accepting this EULA on behalf of a company or other legal entity, you represent that you have authority to bind that entity.

---

## 1. Relationship to other agreements

This EULA applies to the Software. Your right to use Copado products and services may also be governed by a separate agreement with Copado (for example, a master subscription agreement, order form, or customer agreement). If there is a conflict between this EULA and that agreement on a specific point, the separate agreement controls to the extent of the conflict.

Copado may offer this Software at no additional charge as a benefit to eligible Copado customers. Eligibility, scope, and duration of that offering are determined by Copado and your agreement(s) with Copado.

---

## 2. License grant

Subject to this EULA and your compliance with it, Copado grants you a **limited, non-exclusive, non-transferable, non-sublicensable, revocable** license to install and use the Software **only** for your internal business purposes **in connection with your authorized use of Copado’s products or services**, and only for so long as Copado makes the Software available to you.

No license is granted for any purpose not expressly stated above.

---

## 3. Restrictions

You must not, and must not permit others to:

- Copy the Software except as reasonably necessary for backup or disaster recovery in support of your licensed use, or as allowed by applicable law;
- Distribute, rent, lease, lend, sell, sublicense, assign, or otherwise transfer the Software or your rights under this EULA;
- Modify, translate, adapt, or create derivative works of the Software, except as permitted by applicable law notwithstanding this restriction;
- Reverse engineer, decompile, or disassemble the Software, except to the limited extent expressly permitted by applicable law;
- Remove, obscure, or alter proprietary notices on the Software;
- Use the Software to build a competing product or service, or to benchmark or publicly disclose performance results without Copado’s prior written consent;
- Use the Software in violation of applicable law or in a manner that interferes with the security, availability, or integrity of Copado’s or others’ systems;
- Circumvent technical limitations or license keys in the Software.

---

## 4. Third-party and open-source components

The Software may include third-party or open-source components. Required notices and license terms for those components may be provided with the Software (for example in accompanying documentation or package metadata). Those terms apply only to the respective components.

---

## 5. Updates

Copado may provide updates, patches, or new versions of the Software. Unless accompanied by a separate license, updates are subject to this EULA. Copado may change or discontinue features or availability of the Software.

---

## 6. Ownership

Copado and its licensors retain all right, title, and interest in and to the Software and related intellectual property. Except for the limited license in Section 2, no rights are granted to you by implication, estoppel, or otherwise.

---

## 7. Term and termination

This EULA is effective until terminated. Your rights terminate automatically if you fail to comply with this EULA. Copado may suspend or terminate your license if you breach this EULA or if your entitlement to use the Software under your agreement(s) with Copado ends.

Upon termination, you must cease use of the Software and destroy any copies in your possession or control, except copies retained in standard backup media until routinely rotated, unless applicable law requires retention.

---

## 8. Disclaimer of warranties

**To the maximum extent permitted by applicable law, the Software is provided “as is” and “as available,” with all faults and without warranty of any kind.** Copado disclaims all warranties, whether express, implied, statutory, or otherwise, including implied warranties of merchantability, fitness for a particular purpose, title, and non-infringement.

---

## 9. Limitation of liability

**To the maximum extent permitted by applicable law:**

- In no event will Copado be liable for any indirect, incidental, special, consequential, exemplary, or punitive damages, or any loss of profits, revenues, goodwill, or data, arising out of or related to this EULA or the Software, even if advised of the possibility of such damages.
- Copado’s total aggregate liability arising out of or related to this EULA or the Software will not exceed **the greater of (a) the fees you paid Copado specifically for the Software in the twelve (12) months preceding the claim, or (b) one hundred U.S. dollars (USD $100)**, if no such fees were paid.

These limitations apply whether the claim is based in contract, tort, strict liability, or any other theory.

---

## 10. Export compliance

You must comply with all applicable export and sanctions laws and regulations. You represent that you are not prohibited from receiving the Software under applicable law.

---

## 11. General

**Assignment.** You may not assign this EULA without Copado’s prior written consent. Copado may assign this EULA in connection with a merger, acquisition, corporate reorganization, or sale of all or substantially all of its assets.

**Entire agreement.** This EULA, together with any agreement referenced in Section 1, constitutes the entire agreement between you and Copado regarding the Software and supersedes any prior understandings on that subject.

**Severability.** If any provision is held invalid or unenforceable, the remaining provisions remain in effect.

**No waiver.** Failure to enforce a provision is not a waiver.

**Governing law and venue.** This EULA is governed by the laws designated in your governing agreement with Copado (if any); **if none is stated, by the laws of Spain**, excluding its conflict-of-law rules. Courts located in that jurisdiction have exclusive jurisdiction, subject to mandatory provisions of applicable law.

**Contact.** For license questions, contact Copado through your usual Copado support or customer channel.

---

_Copado may update this EULA from time to time. Continued use of the Software after notice of material changes may constitute acceptance._
