
[![pipeline status](https://gitlab.copado.com/app-dev/copado_cli/badges/master/pipeline.svg)](https://gitlab.copado.com/app-dev/copado_cli/commits/master)
[![coverage report](https://gitlab.copado.com/app-dev/copado_cli/badges/master/coverage.svg)](https://gitlab.copado.com/app-dev/copado_cli/commits/master)

# Copado CLI

The Copado CLI is a Salesforce CLI plugin. This tool allows you to execute Copado-related tasks from an IDE/Terminal and leverage Git and Salesforce commands, Agile or issue tracking tools, such as Jira, and user story automation, among other things.

Let’s see how you can configure the CLI and start working with it.

## Requirements and Set Up

**Requirements**

* **Contributors:** Node.js **20** LTS when running `npm test` / `npm run build` locally (matches `.gitlab-ci.yml` and avoids loader issues on newer Node versions).

### Contributors — `sf plugins link` (local checkout)

If you link this repository into the global Salesforce CLI (`sf plugins link .` from the repo root), generate the command manifest **after** every successful compile, **before** (or right after) linking:

```bash
npm install
npm run plugins:link-prep
sf plugins unlink @copado/copado-cli 2>/dev/null || true
sf plugins link .
```

`oclif.manifest.json` is **gitignored**; it is produced by `oclif manifest` and tells the CLI to load **`lib/commands/**/*.js`**. If you skip this step, `sf` may try to JIT-compile TypeScript for the linked plugin and print many **`TSError: Unable to compile TypeScript`** warnings (often with an empty detail line), then **`copado … is not a sf command`**. After `git pull`, run **`npm run plugins:link-prep`** again, then re-link.

### First run (sf CLI)

1. Authenticate a Salesforce org and set a default (`sf org login web` / `sf config set target-org …`).
2. Link that org to Copado CLI: `sf copado auth set -u <username>` (or pass the username as a positional argument).
3. Optional: run **`sf copado setup`** to pick a role and create a starter **`.copado/queries.json`** (Developer preset).
4. Prefer canonical topics: **`sf copado story …`** (user stories), **`sf copado auth get`**, **`sf copado job get`**, **`sf copado env list`**, **`sf copado repo list`**. Legacy `work`, `auth display`, `job status`, `environment list`, and `repository list` still work but print a one-line deprecation on stderr (suppressed with `--json`).

In order to start using the Copado CLI, you need the following elements:

* Salesforce User and Managed Package licenses.
* Copado Winter '20 (v15).
* Copado org credential.
* Copado license.
* Branch management [pipeline](https://docs.copado.com/article/ckxswevdln-pipeline).
* Salesforce CLI.
* Git

**Installation**

1. First of all, you need to download and install [Salesforce CLI](https://developer.salesforce.com/tools/sfdxcli), as Copado CLI is a Salesforce CLI plugin.

2. Insert the following command to install the Copado plugin: 
        
        sfdx plugins:install @copado/copado-cli

    During the installation process, both plugin and dependencies will be installed.

3. Link your Salesforce CLI with your Copado CLI using this command: 
        
        sfdx copado:auth:set -u [user@mycompany.com]

    Where the username is the org credential you have already authenticated in Copado. You can use this command to authenticate the org where you have Copado installed.

        sfdx force:auth:web:login

4. You can authenticate multiple orgs to work with the CLI and then use the command 

        sfdx force:org:list

    In order to get the list of orgs that have been authenticated and their corresponding org Id.

Now that you know what the Copado CLI is and how you can set it up, take a look at our [CLI Commands](https://docs.copado.com/article/uw57rcwkhx-cli-commands) article to learn more about the actions you can perform with the CLI.

## VS Code extension (experimental)

A sibling package under **`vscode-extension/`** wraps **`sf copado …`** for the editor (argv-only subprocess, no Copado Apex REST from the extension). It adds **Quick actions** (QuickPick over the registry), an **activity bar** view, **Git SCM title** shortcuts, a **status bar** entry, output **redaction**, and a **six-step Getting Started walkthrough** (`copado.firstRun`). See **`vscode-extension/README.md`** for trust/cwd behavior, troubleshooting, F5, and `copado.salesforceCliPath`.
